update_master <- function() {
  devtools::install_github("slfan2013/WCMC_DA/WCMC.Course2017.STAT",force=T)
}
