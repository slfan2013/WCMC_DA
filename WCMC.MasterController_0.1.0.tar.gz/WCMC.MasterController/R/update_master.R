update_master <- function() {
  install.packages("https://github.com/slfan2013/WCMC_DA/raw/master/WCMC.Course2017.STAT_0.1.0.tar.gz",repos=NULL)
}
